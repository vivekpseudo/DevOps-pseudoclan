import gradio as gr

def fastapi_ui(text, source_lang, target_lang):
    from fastapi.testclient import TestClient
    client = TestClient(app)
    response = client.post(
        "/text-to-speech/",
        data={"text": text, "source_lang": source_lang, "target_lang": target_lang}
    )
    return response.content

gr.Interface(
    fn=fastapi_ui,
    inputs=[
        gr.Textbox(label="Text to Translate and Speak"),
        gr.Textbox(label="Source Language Code (e.g., en)"),
        gr.Textbox(label="Target Language Code (e.g., hi)")
    ],
    outputs=gr.Audio(label="Generated Speech"),
    title="Text Translator + Speech Generator"
).launch(server_name="0.0.0.0", server_port=7860)
